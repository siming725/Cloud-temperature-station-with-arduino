var pos_info = [
  {
	"name":"test",
    "Channel_ID":'512159',
	"pos_x": 53.103808,
	"pos_y": 8.850050
  },
    {
	"name":"test2",
    "Channel_ID":'514754',
	"pos_x": 53.093388,
	"pos_y": 8.884358
  },
    {
	"name":"test3",
    "Channel_ID":'514754',
	"pos_x": 53.094264,
	"pos_y": 8.831400
  },
    {
	"name":"test4",
    "Channel_ID":'514754',
	"pos_x": 53.068796,
	"pos_y": 8.837776
  },

]
