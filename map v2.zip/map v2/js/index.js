var map;
var myCenter=new google.maps.LatLng(51.508742,-0.120850);
var api_key = "9X25DXI14O03COXO";
var Channel_ID = [];
var markers = [] ;
var infowindow = [];
var timer

function initialize()
{
	var mapProp = {
		center:myCenter,
		zoom:6,
		mapTypeId:google.maps.MapTypeId.ROADMAP
		};
	map = new google.maps.Map(document.getElementById("googleMap"),mapProp);

	place_init();
	timer = window.setInterval(updata,15000);

}

String.prototype.format=function()
{
  if(arguments.length==0) return this;
  for(var s=this, i=0; i<arguments.length; i++)
    s=s.replace(new RegExp("\\{"+i+"\\}","g"), arguments[i]);
  return s;
};

function place_init() {
	for(var j = 0;j<pos_info.length;j++){
		var place = pos_info[j];
		var position = new google.maps.LatLng(place.pos_x,place.pos_y);
		Channel_ID[j] = place.Channel_ID;
		markers[j] = new google.maps.Marker({
			position: position,
			map: map,
		  });
		infowindow[j] = new google.maps.InfoWindow({
		content:'<div id="content">T: {0}℃  H: {1}%</div>'.format(0,0)
		});
		infowindow[j].open(map,markers[j]);
	}
	console.log(infowindow[0]);
	console.log(infowindow[0].setSize(8));

}

function updata() {
	$.ajaxSettings.async = false;
	for(var j = 0;j<Channel_ID.length;j++){
			var url = "api.thingspeak.com/channels/{0}/feeds.json?api_key={1}&results=1".format(Channel_ID[j], api_key);
			$.getJSON('http://'+url,timeout=10,function(result) {
				var data = result['feeds'].pop()
				console.log(data);
				var content = '<div id="content">' +
				'T: {0}℃  H: {1}%'.format(data.field1, data.field2 )
				+'</div>'
				infowindow[j].setContent(content);
		});
	}
}
